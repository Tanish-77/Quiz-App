const question = document.getElementById("question");
const choices = Array.from(document.getElementsByClassName("choice-text"));
const progressText = document.getElementById("progressText");
const scoreText = document.getElementById("score");
const progressBarFull = document.getElementById("progressBarFull");

let currentQuestion = {};
let acceptingAnswers = false;
let score = 0;
let questionCounter = 0;
let availableQuestions = [];

let questions = [
  {
    question: "What is the Caital of INDIA ?",
    choice1: "America",
    choice2: "New Delhi",
    choice3: "Mumbai",
    choice4: "Kolkata",
    answer: 2,
  },
  {
    question: "How many overs are there in a ODI ?",
    choice1: "20",
    choice2: "40",
    choice3: "50",
    choice4: "90",
    answer: 3,
  },
  {
    question: "Who is the No 1 President in India ?",
    choice1: "Sarvepalli Radhakrishnan",
    choice2: "Rajendra Prasad ",
    choice3: "Zakhir Hussain",
    choice4: "Droupadi Murmu",
    answer: 2,
  },
  {
    question: "How many union territories are there in India in 2024 ?",
    choice1: "7",
    choice2: "8",
    choice3: "6",
    choice4: "9",
    answer: 2,
  },
  {
    question: "How many district in haryana ?",
    choice1: "21",
    choice2: "22",
    choice3: "23",
    choice4: "24",
    answer: 2,
  },
  {
    question: "What is the real capital of Punjab?",
    choice1: "Haryana",
    choice2: "Amritsar",
    choice3: "Chandigarh",
    choice4: "Himachal pradesh",
    answer: 3,
  },
  {
    question: "How many days are there in a year?",
    choice1: "364",
    choice2: "366",
    choice3: "365",
    choice4: "363",
    answer: 3,
  },
  {
    question: "How many letters are there in the English alphabet?",
    choice1: "25",
    choice2: "27",
    choice3: "26",
    choice4: "28",
    answer: 3,
  },
  {
    question: "Which animal is known as the king of the jungle?",
    choice1: "Lion",
    choice2: "Tiger",
    choice3: "Dog",
    choice4: "Women",
    answer: 1,
  },
  {
    question: " How many minutes are there in an hour?",
    choice1: "60",
    choice2: "59",
    choice3: "61",
    choice4: "45",
    answer: 1,
  },
];

const CORRECT_BONUS = 10;
const MAX_QUESTIONS = 10;

startGame = () => {
  questionCounter = 0;
  score = 0;
  availableQuestions = [...questions];
  //console.log(availableQuestions);
  getNewQuestion();
};

getNewQuestion = () => {
  if (availableQuestions.length === 0 || questionCounter >= MAX_QUESTIONS) {
    localStorage.setItem("mostRecentScore", score);
    return window.location.assign("end.html");
  }
  questionCounter++;
  progressText.innerText = ` Question ${questionCounter}/${MAX_QUESTIONS}`;

  progressBarFull.style.width = `${
    ((questionCounter - 1) / MAX_QUESTIONS) * 100
  }%`;

  const questionIndex = Math.floor(Math.random() * availableQuestions.length);
  currentQuestion = availableQuestions[questionIndex];
  question.innerText = currentQuestion.question;

  choices.forEach((choice) => {
    const number = choice.dataset["number"];
    choice.innerText = currentQuestion["choice" + number];
  });

  availableQuestions.splice(questionIndex, 1);

  acceptingAnswers = true;
};

choices.forEach((choice) => {
  choice.addEventListener("click", (e) => {
    // console.log(e.target);
    if (!acceptingAnswers) return;

    acceptingAnswers = false;
    const selectedChoice = e.target;
    const selectedAnswer = selectedChoice.dataset["number"];

    let classToApply = "incorrect";
    if (selectedAnswer == currentQuestion.answer) {
      classToApply = "correct";
    }
    //let classToApply = selectedAnswer == currentQuestion.answer ? "correct" : "incorrect";

    if (classToApply === "correct") {
      incrementScore(CORRECT_BONUS);
    }
    selectedChoice.parentElement.classList.add(classToApply);
    setTimeout(() => {
      selectedChoice.parentElement.classList.remove(classToApply);
      getNewQuestion();
    }, 1000);
  });
});

incrementScore = (num) => {
  score += num;
  scoreText.innerText = score;
};

startGame();
